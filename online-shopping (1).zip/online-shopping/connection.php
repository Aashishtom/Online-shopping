<?php
//$con=mysqli_connect("localhost","root","","store") or die(mysqli_error($con));
$con=mysqli_connect("172.17.0.3","root","password","store") or die(mysqli_error($con));
?>
